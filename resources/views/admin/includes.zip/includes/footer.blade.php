<footer class="footer text-center">
    All Rights Reserved by CDS Company. Designed and Developed by <a href="https://midhawk.com/">Midhawk</a>.
</footer>

<script>
    function openNav() {
        var e = document.getElementById("mySidenav");
        if (e.style.width == '250px')
        {
            e.style.width = '0px';
        }
        else
        {
            e.style.width = '250px';
        }
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
</script>
